import SwiftUI

struct ProfileFundsView: View {
    @Binding var isPresented: Bool
    @State private var selectedObjective: String = ""
    @State private var selectedRiskTolerance: String = ""
    @State private var investmentAmount: Double = 0.0
    @State private var showAdditionalQuestions = false

    var body: some View {
        VStack {
            Text("Perfil de Inversión")
                .font(.largeTitle)
                .padding()
            
            // Pregunta 1: Objetivo principal de inversión
            Text("¿Cuál es tu objetivo principal de inversión?")
                .font(.headline)
                .padding()
            
            Picker("Selecciona un objetivo", selection: $selectedObjective) {
                Text("Crecimiento a largo plazo").tag("Crecimiento")
                Text("Ingresos regulares").tag("Ingresos")
                Text("Preservación de capital").tag("Preservación")
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()
            
            // Pregunta 2: Tolerancia al riesgo
            Text("¿Cuál es tu tolerancia al riesgo?")
                .font(.headline)
                .padding()
            
            Picker("Selecciona una tolerancia", selection: $selectedRiskTolerance) {
                Text("Baja").tag("Baja")
                Text("Moderada").tag("Moderada")
                Text("Alta").tag("Alta")
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()
            
            // Pregunta 3: Monto de inversión
            Text("¿Cuál es el monto que deseas invertir?")
                .font(.headline)
                .padding()
            
            Slider(value: $investmentAmount, in: 0...100000, step: 1000)
                .padding()
            
            Text("\(Int(investmentAmount)) USD")
                .padding()
            
            Button(action: {
                // Cierra la hoja emergente actual
                isPresented = false
                
                // Muestra la siguiente hoja emergente con preguntas adicionales
                showAdditionalQuestions = true
            }) {
                Text("Continuar")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding()
            .sheet(isPresented: $showAdditionalQuestions) {
                AdditionalQuestionsView(isPresented: self.$showAdditionalQuestions)
            }
        }
    }
}
