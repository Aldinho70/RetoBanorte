import SwiftUI

struct SecondSheetView: View {
    @Binding var isPresented: Bool
    var cardTitle: String
    @Binding var isShowingProfileFundsView: Bool // Agregamos una variable de estado para controlar la tercera hoja emergente

    var body: some View {
        VStack {
            Text("Segunda Página Emergente")
                .font(.largeTitle)
                .padding()

            Image(systemName: "photo") // Reemplaza con la imagen aleatoria
                .resizable()
                .frame(width: 100, height: 100)
                .padding()

            Text("Texto específico sobre el tema")

            Button(action: {
                // Cierra la segunda hoja emergente
                isPresented = false
                // Muestra la tercera hoja emergente (ProfileFundsView)
                isShowingProfileFundsView = true
            }) {
                Text("Continuar")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding()

            Spacer()

            Button(action: {
                // Cierra la segunda hoja emergente
                isPresented = false
            }) {
                Text("Menú")
                    .foregroundColor(.blue)
                    .padding()
            }
            .padding()
        }
    }
}
