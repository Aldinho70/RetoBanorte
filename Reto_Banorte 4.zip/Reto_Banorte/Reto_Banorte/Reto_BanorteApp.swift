//
//  Reto_BanorteApp.swift
//  Reto_Banorte
//
//  Created by Victor on 23/09/23.
//

import SwiftUI

@main
struct Reto_BanorteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
