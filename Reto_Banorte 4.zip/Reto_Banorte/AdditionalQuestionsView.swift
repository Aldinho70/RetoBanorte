import SwiftUI

struct AdditionalQuestionsView: View {
    @Binding var isPresented: Bool
    @State private var question1Answer = ""
    @State private var question2Answer = ""
    
    var body: some View {
        VStack {
            Text("Preguntas Adicionales")
                .font(.largeTitle)
                .padding()
            
            // Pregunta adicional 1
            Text("¿Cuál es tu pregunta adicional 1?")
                .font(.headline)
                .padding()
            
            TextField("Respuesta", text: $question1Answer)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            // Pregunta adicional 2
            Text("¿Cuál es tu pregunta adicional 2?")
                .font(.headline)
                .padding()
            
            TextField("Respuesta", text: $question2Answer)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button(action: {
                // Realiza acciones con las respuestas si es necesario
                
                // Cierra la hoja emergente
                isPresented = false
            }) {
                Text("Finalizar")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
            .padding()
        }
    }
}

// Asegúrate de que AdditionalQuestionsView esté definida fuera de cualquier otra vista.
