import SwiftUI

struct ContentView: View {
    @State private var checklistItems: [String] = []
    @State private var selectedCardTitle: CardTitle? = nil
    @State private var isShowingSecondSheet = false
    @State private var isShowingProfileFundsView = false
    @State private var randomImageName: String = "photo"

    struct CardTitle: Identifiable {
        let id = UUID()
        let title: String
    }

    var body: some View {
        NavigationView {
            VStack {
                ZStack {
                    Color.red
                        .frame(height: 120)
                        .edgesIgnoringSafeArea(.top)

                    HStack {
                        Image(systemName: "arrow.left")
                            .foregroundColor(.white)
                            .padding()

                        Text("Contrata Productos")
                            .font(.largeTitle)
                            .foregroundColor(.white)

                        Spacer()
                    }
                }

                ScrollView {
                    VStack(spacing: 20) {
                        HStack(spacing: 20) {
                            createCardWithTitle("Tarjeta de Crédito", titleForSheet: "Tarjeta de Crédito")
                            createCardWithTitle("Pagare", titleForSheet: "Pagare")
                        }

                        HStack(spacing: 20) {
                            createCardWithTitle("Crédito de Nómina", titleForSheet: "Crédito de Nómina")
                            createCardWithTitle("Fondos de Inversión", titleForSheet: "Fondos de Inversión")
                        }

                        HStack(spacing: 20) {
                            createCardWithTitle("Adelanto de Nómina", titleForSheet: "Adelanto de Nómina")
                            createCardWithTitle("Seguros", titleForSheet: "Seguros")
                        }

                        HStack(spacing: 20) {
                            createCardWithTitle("Tarjetas Adicionales", titleForSheet: "Tarjetas Adicionales")
                        }
                    }
                    .padding()
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $isShowingSecondSheet, onDismiss: {
                isShowingSecondSheet = false
            }) {
                NavigationView {
                    SecondSheetView(isPresented: $isShowingSecondSheet, cardTitle: selectedCardTitle?.title ?? "", isShowingProfileFundsView: $isShowingProfileFundsView)
                }
            }
            .sheet(isPresented: $isShowingProfileFundsView) {
                ProfileFundsView(isPresented: $isShowingProfileFundsView)
            }
        }
    }

    private func createCardWithTitle(_ title: String, titleForSheet: String) -> some View {
        Button(action: {
            selectedCardTitle = CardTitle(title: titleForSheet)
            isShowingSecondSheet = true
        }) {
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: 150, height: 150)
                    .foregroundColor(Color.black)
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: 150, height: 150)
                    .foregroundColor(Color.gray)
                    .opacity(0.8)
                    .overlay(
                        Text(title)
                            .foregroundColor(.white)
                    )
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
