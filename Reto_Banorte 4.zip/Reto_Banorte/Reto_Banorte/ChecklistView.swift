//
//  ChecklistView.swift
//  Reto_Banorte
//
//  Created by Victor on 23/09/23.
//

import Foundation
