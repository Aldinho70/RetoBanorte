import SwiftUI
struct ChecklistView: View {
    @Binding var checklistItems: [String]
    var cardTitle: String
    
    var body: some View {
        VStack {
            Text("\(cardTitle)")
                .font(.headline)
                .padding()
            
            List(checklistItems, id: \.self) { item in
                HStack {
                    Image(systemName: "checkmark.circle")
                        .foregroundColor(.green)
                    Text(item)
                        .foregroundColor(.primary)
                }
            }
            
            Button(action: {
                // Agregar elementos a la lista de verificación si es necesario
                // checklistItems.append("Nuevo elemento")
            }) {
                Text("Agregar elemento")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()
        }
    }
}
